import { Page, Locator } from "@playwright/test";
import { BasePage } from "./basePage";

export class AccountCreatedPage extends BasePage {
	readonly accountCreatedRoot: Locator;
	readonly successMessage: Locator;
	readonly continueButton: Locator;

	constructor(page: Page) {
		super(page);
		this.accountCreatedRoot = page.locator("#form");
		this.successMessage = page.getByTestId("account-created");
		this.continueButton = page.getByTestId("continue-button");
	}

	async waitForRoot() {
		await this.accountCreatedRoot.waitFor({ state: "visible" });
	}

	async clickContinueButton() {
		await this.continueButton.click();
	}
}
